import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class PlaylistManager {
    private Map<String, List<String>> playlists;

    public PlaylistManager() {
        this.playlists = new HashMap<>();
    }

    public void criarPlaylist(Scanner scanner) {
        System.out.print("Digite o nome da playlist: ");
        String nomePlaylist = scanner.nextLine();
        playlists.put(nomePlaylist, new ArrayList<>());
        System.out.println("Playlist '" + nomePlaylist + "' criada com sucesso!");
    }

    public void adicionarMusicaPlaylist(Scanner scanner, MusicManager musicManager) {
        System.out.println("Playlists disponíveis:");
        for (String playlistNome : playlists.keySet()) {
            System.out.println("- " + playlistNome);
        }

        System.out.print("Digite o nome da playlist que deseja adicionar a música: ");
        String nomePlaylist = scanner.nextLine();
        if (!playlists.containsKey(nomePlaylist)) {
            System.out.println("Playlist '" + nomePlaylist + "' não encontrada!");
            return;
        }

        List<String> playlist = playlists.get(nomePlaylist);
        musicManager.exibirMusicasDisponiveis();
        System.out.print("Digite o número da música que deseja adicionar à playlist '" + nomePlaylist + "': ");
        int escolhaMusica = scanner.nextInt();
        scanner.nextLine();

        String musicaSelecionada = musicManager.getMusica(escolhaMusica);
        if (musicaSelecionada == null) {
            System.out.println("Opção inválida.");
        } else {
            playlist.add(musicaSelecionada);
            System.out.println("Música '" + musicaSelecionada + "' adicionada à playlist '" + nomePlaylist + "' com sucesso!");
        }
    }

    public void verPlaylists() {
        if (playlists.isEmpty()) {
            System.out.println("Não há playlists criadas.");
        } else {
            for (Map.Entry<String, List<String>> entry : playlists.entrySet()) {
                System.out.println("Playlist: " + entry.getKey());
                List<String> musicas = entry.getValue();
                if (musicas.isEmpty()) {
                    System.out.println("   Nenhuma música adicionada.");
                } else {
                    for (String musica : musicas) {
                        System.out.println("   " + musica);
                    }
                }
            }
        }
    }
}
