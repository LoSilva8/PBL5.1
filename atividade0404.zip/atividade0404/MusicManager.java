import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MusicManager {
    private List<String> musicas;

    public MusicManager() {
        this.musicas = new ArrayList<>();
        inicializarMusicas();
    }

    private void inicializarMusicas() {
        musicas.add("1. Música 1 - Cantor 1");
        musicas.add("2. Música 2 - Cantor 2");
        musicas.add("3. Música 3 - Cantor 3");
        musicas.add("4. Música 4 - Cantor 4");
        musicas.add("5. Música 5 - Cantor 5");
        musicas.add("6. Música 6 - Cantor 6");
        musicas.add("7. Música 7 - Cantor 7");
        musicas.add("8. Música 8 - Cantor 8");
        musicas.add("9. Música 9 - Cantor 9");
        musicas.add("10. Música 10 - Cantor 10");
    }

    public void menuMusicas(Scanner scanner) {
        int escolha;
        do {
            System.out.println("\n=== Músicas ===");
            System.out.println("1. Ver Músicas Disponíveis");
            System.out.println("2. Adicionar Música");
            System.out.println("0. Voltar ao Menu Principal");
            System.out.print("Escolha uma opção: ");

            escolha = scanner.nextInt();
            scanner.nextLine(); 

            switch (escolha) {
                case 1:
                    exibirMusicasDisponiveis();
                    break;
                case 2:
                    adicionarMusica(scanner);
                    break;
                case 0:
                    System.out.println("Voltando ao Menu Principal...");
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }
        } while (escolha != 0);
    }

    public void exibirMusicasDisponiveis() {
        for (String musica : musicas) {
            System.out.println(musica);
        }
    }

    public void adicionarMusica(Scanner scanner) {
        System.out.print("Digite o nome da música: ");
        String nomeMusica = scanner.nextLine();
        System.out.print("Digite o nome do cantor: ");
        String nomeCantor = scanner.nextLine();
        musicas.add((musicas.size() + 1) + ". " + nomeMusica + " - " + nomeCantor);
        System.out.println("Música adicionada com sucesso!");
    }

    public String getMusica(int index) {
        if (index > 0 && index <= musicas.size()) {
            return musicas.get(index - 1);
        }
        return null;
    }
}
