import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PlaylistManager playlistManager = new PlaylistManager();
        MusicManager musicManager = new MusicManager();

        System.out.println("Bem-vindo ao Nosso Site!");
        System.out.print("Por favor, digite seu nome: ");
        String nomeUsuario = scanner.nextLine();

        int escolha;
        do {
            System.out.println("\n===== Menu =====");
            System.out.println("1. Músicas");
            System.out.println("2. Criar Playlist");
            System.out.println("3. Adicionar Música à Playlist");
            System.out.println("4. Ver Playlists");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");

            escolha = scanner.nextInt();
            scanner.nextLine();

            switch (escolha) {
                case 1:
                    musicManager.menuMusicas(scanner);
                    break;
                case 2:
                    playlistManager.criarPlaylist(scanner);
                    break;
                case 3:
                    playlistManager.adicionarMusicaPlaylist(scanner, musicManager);
                    break;
                case 4:
                    playlistManager.verPlaylists();
                    break;
                case 0:
                    System.out.println("Saindo...");
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }
        } while (escolha != 0);

        scanner.close();
    }
}
